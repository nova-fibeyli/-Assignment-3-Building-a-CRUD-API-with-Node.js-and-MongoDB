
#!/bin/bash
# Install required dependencies
echo "Installing dependencies..."
npm install

# Run the server
echo "Starting the server..."
node server.js
