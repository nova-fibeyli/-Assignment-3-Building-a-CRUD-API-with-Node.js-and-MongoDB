const express = require("express");
const router = express.Router();
const blogController = require("../controllers/blogController");

// Create a new blog
router.post("/blogs", blogController.createBlog);

// Get all blogs
router.get("/blogs", blogController.getBlogs);

// Get a blog by ID
router.get("/blogs/:id", blogController.getBlogById);

// Update a blog
router.put("/blogs/:id", blogController.updateBlog);

// Delete a blog
router.delete("/blogs/:id", blogController.deleteBlog);

module.exports = router;
