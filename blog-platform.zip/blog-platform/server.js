// 1-step: node server.js
// 2-step: Open postman
// 3-step: + request
// 4-step: Select method as POST
// 5-step: In url filed: http://localhost:5000/api/blogs
// 6-step: Click body
// 7-step: Select raw and set the format to JSON
// 8-step: Paste something like: {;  "title": "My First Blog",;  "content": "This is the content of my first blog post.";}

// 9-step: + request
// 10-step: Select method as GET
// 11-step: Enter the URL: http://localhost:5000/api/blogs
// 12-step: Click the Send button

// 13-step: + request
// 14-step: Select method as PUT
// 15-step: Enter the URL: http://localhost:5000/api/blogs/67897a830e1932d952a643
// 16-step: Paste something like: {;  "title": "Updated Blog Title",;  "content": "This is the updated content of the blog.",;  "author": "Updated Author";}
// 17-step: Click the Send button

// 18-step: + request
// 19-step: Select method as DELETE
// 20-step: Enter the URL: DELETE /api/blogs/:id
// 21-step: Paste something like: {;  "title": "Updated Blog Title",;  "content": "This is the updated content of the blog.",;  "author": "Updated Author";}
// 22-step: Click the Send button

const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const connectDB = require("./config/db");
const blogRoutes = require("./routes/blogRoutes");
require("dotenv").config();

// Middleware
const app = express();
app.use(cors());
app.use(bodyParser.json());

// Connect to MongoDB
connectDB();

// Routes
app.use("/api", blogRoutes);

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () =>
  console.log(`Server running at http://localhost:${PORT}`)
);
